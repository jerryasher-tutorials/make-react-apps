// hard coding in products right here. you would most likely grab these from an api
export default [
  {
    sku: 123,
    name: 'Occupy Mars Shirt',
    image_url: 'https://i.imgur.com/dHzSCmK.png',
    price: 20,
  },
  {
    sku: 456,
    name: 'Starman Shirt',
    image_url: 'https://i.imgur.com/uKxQCRX.png',
    price: 30,
  },
  {
    sku: 789,
    name: 'Crew Dragon Shirt',
    image_url: 'https://i.imgur.com/5X6jmXs.png',
    price: 40,
  },
  {
    sku: 1011,
    name: 'Ripley Shirt',
    image_url: 'https://i.imgur.com/eeZ3FQE.png',
    price: 50,
  },
];
